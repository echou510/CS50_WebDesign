const canvas = document.querySelector('canvas'); 
const ctx;  

if (canvas.getContext)
    {   ctx = canvas.getContext('2d'); 
    }
