const cvs = document.getElementById("traffic");
const ctx = cvs.getContext("2d");
var state =0; 
var game=0; 
function drawCircle(c, pos){
    ctx.beginPath();
    ctx.arc(cvs.width/2, cvs.height/6+pos*200, 75, 0, 2 * Math.PI);
    ctx.fillStyle = c; 
    ctx.fill(); 
    ctx.strokeStyle = "black"; 
    ctx.lineWidth = 3; 
    ctx.stroke();
    ctx.closePath(); 
}
function draw(){
    ctx.clearRect(0, 0, cvs.width, cvs.height); 
    ctx.fillStyle = "black"; 
    ctx.fillRect(4, 4, cvs.width-8, cvs.height-8); 
    switch (state) {
        case 0: 
            drawCircle("gray", 0); 
            drawCircle("gray", 1); 
            drawCircle("gray", 2); state = 0; break; 
        case 1: 
            drawCircle("green", 0); 
            drawCircle("gray", 1); 
            drawCircle("gray", 2); state = 2; break; 
        case 2: 
            drawCircle("gray", 0); 
            drawCircle("yellow", 1); 
            drawCircle("gray", 2); state = 3; break; 
        case 3: 
            drawCircle("gray", 0); 
            drawCircle("gray", 1); 
            drawCircle("red", 2); state = 1; break; 
    }
}
function start(){
  state=1; 
}
function stop(){
    clearInterval(game);  
}
state = 0;
game = setInterval(draw,3000);