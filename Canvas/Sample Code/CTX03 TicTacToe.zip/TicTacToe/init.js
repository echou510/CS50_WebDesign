const canvas = document.querySelector('canvas'); 
const ctx;  

canvas.width  = window.innerWidth;
canvas.height = window.innerHeight;
if (canvas.getContext)
    {   ctx = canvas.getContext('2d'); 
    }

const debounce = (func) => {
  let timer;
  return (event) => {
    if (timer) { clearTimeout(timer) }
    timer = setTimeout(func, 100, event);
  }
}

window.addEventListener('resize', debounce(() => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
})) 
