function main(){
 alert("JavaScript in External File."); 
}
